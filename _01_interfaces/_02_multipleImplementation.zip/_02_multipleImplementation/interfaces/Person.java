package _01_interfaces._02_multipleImplementation.interfaces;

/**
 * Created by User on 16.07.2016.
 */
public interface Person {

    String getName();

    int getAge();
}
