package _01_interfaces._03_ferrari.interfaces;

/**
 * Created by User on 16.07.2016.
 */
public interface Car {
    String getMODEL();
    String brakes();
    String gasPush();

}
