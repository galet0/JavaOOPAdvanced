package _01_interfaces._04_telephony.interfaces;

/**
 * Created by User on 16.07.2016.
 */
public interface Phone {
    String call(String number);

}
