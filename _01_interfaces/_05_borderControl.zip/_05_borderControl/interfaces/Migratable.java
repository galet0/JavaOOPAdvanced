package _01_interfaces._05_borderControl.interfaces;

/**
 * Created by User on 17.07.2016.
 */
public interface Migratable {

    String getId();

    void detained(String fakeId);

}
