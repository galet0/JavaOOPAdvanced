package _01_interfaces._06_birthdayCelebrations.interfaces;

/**
 * Created by User on 17.07.2016.
 */
public interface Birthable {

    //String getBirthday();

    void printBirthday(String date);

}
