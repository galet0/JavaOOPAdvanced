package _01_interfaces._06_birthdayCelebrations.models;

/**
 * Created by User on 17.07.2016.
 */
public class Population {

    private String name;

    public Population(String name) {
        this.name = name;
    }


}
