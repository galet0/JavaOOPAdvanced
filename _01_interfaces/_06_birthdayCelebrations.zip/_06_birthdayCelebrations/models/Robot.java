package _01_interfaces._06_birthdayCelebrations.models;

/**
 * Created by User on 17.07.2016.
 */
public class Robot extends Population {
    private String id;

    public Robot(String name, String id) {
        super(name);
        this.id = id;
    }
}
