package _01_interfaces._07_foodShortage.interfaces;

/**
 * Created by User on 17.07.2016.
 */
public interface Buyer {

    int buyFood();

    int getFood();
}
