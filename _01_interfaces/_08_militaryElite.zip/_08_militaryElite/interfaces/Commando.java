package _01_interfaces._08_militaryElite.interfaces;

import java.util.Collection;

/**
 * Created by User on 18.07.2016.
 */
public interface Commando {
    Collection<Mission> getMissions();
}
