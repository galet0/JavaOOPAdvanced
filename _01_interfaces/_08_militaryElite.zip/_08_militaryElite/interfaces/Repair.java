package _01_interfaces._08_militaryElite.interfaces;

/**
 * Created by User on 18.07.2016.
 */
public interface Repair {
    String getPartName();
    int getHoursWorked();
}
