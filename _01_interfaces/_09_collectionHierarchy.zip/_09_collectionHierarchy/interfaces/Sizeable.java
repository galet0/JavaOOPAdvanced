package _01_interfaces._09_collectionHierarchy.interfaces;

/**
 * Created by User on 19.07.2016.
 */
public interface Sizeable extends Removeable{

    Integer used();

}