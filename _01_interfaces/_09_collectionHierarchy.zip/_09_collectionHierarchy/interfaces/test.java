package _01_interfaces._09_collectionHierarchy.interfaces;

/**
 * Created by User on 19.07.2016.
 */
public interface test extends Addable, Removeable, Sizeable{

}
