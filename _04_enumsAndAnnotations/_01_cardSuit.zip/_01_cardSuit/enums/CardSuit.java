package _04_enumsAndAnnotations._01_cardSuit.enums;

/**
 * Created by User on 26.07.2016.
 */
public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
