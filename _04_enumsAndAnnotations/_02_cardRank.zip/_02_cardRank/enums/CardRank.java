package _04_enumsAndAnnotations._02_cardRank.enums;

/**
 * Created by User on 27.07.2016.
 */
public enum CardRank {
    ACE,
    TWO,
    THREE,
    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    TEN,
    JACK,
    QUEEN,
    KING
}
