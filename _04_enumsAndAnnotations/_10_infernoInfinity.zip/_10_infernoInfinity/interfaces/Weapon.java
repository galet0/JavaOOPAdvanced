package _04_enumsAndAnnotations._10_infernoInfinity.interfaces;

import _04_enumsAndAnnotations._10_infernoInfinity.enums.Gem;

/**
 * Created by User on 27.07.2016.
 */
public interface Weapon {
    void addGem(Gem gem, int index);
    void removeGem(int index);
    String getName();
}
