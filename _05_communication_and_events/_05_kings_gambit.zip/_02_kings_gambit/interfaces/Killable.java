package _05_communication_and_events._02_kings_gambit.interfaces;


public interface Killable {
    void handleRespondToAttack();
}
