package _05_communication_and_events._02_kings_gambit.interfaces;

/**
 * Created by User on 02.08.2016.
 */
public interface Namable {
    String getName();
}
